
import brenda.array.Array;
import brenda.listsingly.LinkedList;
import brenda.map.Map;
import brenda.tree.BinaryTree;
import brenda.tree.Node;
import brenda.util.iterator.Iterator;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;


public class tests {
    @Test
    void containsArray1() {
        Node<String> root = new Node<>("+", new Node<>("*", new Node<>("a"), new Node<>("b")), new Node<>("/", new Node<>("c"), new Node<>("d")));
    }
    
    @Test
    public void testContarColisiones() {
        Map<Integer> mapa = new Map<>(4);

        mapa.put("a343", 1);
        mapa.put("k4356456", 2);
        mapa.put("t6546546", 3);
        mapa.put("e234", 4);

        assertEquals(2, mapa.colisiones());
    }

    @Test
    public void testColisiones2() {
    }
}
