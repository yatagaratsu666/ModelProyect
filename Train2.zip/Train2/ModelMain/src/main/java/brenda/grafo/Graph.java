package brenda.grafo;

import brenda.array.Array;
import brenda.listsingly.LinkedList;
import java.io.Serializable;

public class Graph<E> implements Serializable{
    
    public GraphNode<E> first;
    public GraphNode<E> last;
    public LinkedList<LinkedList<E>> allPaths;

    public Graph() {
        first = null;
        last = null;
        allPaths = new LinkedList<>();

    }

    public boolean isEmpty() {
        return first == null;
    }

    public boolean contains(E element) {
        boolean contains = false;
        if (!isEmpty()) {
            GraphNode<E> temporal = first;
            while (temporal != null && !contains) {
                if (temporal.data.toString().equals(element.toString())) {
                    contains = true;
                }
                temporal = temporal.next;
            }
        }
        return contains;
    }

    public void newEdge(E from, E to) {
        GraphNode<E> position = getNodeByData(from);
        if (position != null && contains(to)) {
            position.list.newAdjacency(to);
        } else {
            System.out.println("El nodo de origen o destino no existe en el grafo.");
        }
    }
    
    public void newEdge(E from, E to, float weight) {
        GraphNode<E> position = getNodeByData(from);
        if (position != null && contains(to)) {
            position.list.newAdjacency(to, weight);
        } else {
            System.out.println("El nodo de origen o destino no existe en el grafo.");
        }
    }

    public void newNode(E element) {
        if (!contains(element)) {
            GraphNode<E> node = new GraphNode<>(element);
            if (isEmpty()) {
                first = node; 
                last = node;
            } else {
                if (element.toString().compareTo(first.data.toString()) <= 0) {
                    node.next = first;
                    first = node;    
                } else {
                    GraphNode<E> temporal = first;
                    while (temporal.next != null && element.toString().compareTo(temporal.next.data.toString()) > 0) {
                        temporal = temporal.next;
                    }
                    node.next = temporal.next;
                    temporal.next = node;
                }
            }
        }
    }

    public int getSize() {
        int size = 0;
        GraphNode<E> current = first;
        while (current != null) {
            size++;
            current = current.next;
        }
        return size;
    }
    
    public int getNodeIndex(E nodeData) {
        int index = 0;
        GraphNode<E> current = first;
        while (current != null) {
            if (current.data.equals(nodeData)) {
                return index;
            }
            index++;
            current = current.next;
        }
        return -1;
    }

    public int getNodeIndex(GraphNode<E> node) {
        int index = 0;
        GraphNode<E> current = first;
        while (current != null) {
            if (current == node) {
                return index;
            }
            index++;
            current = current.next;
        }
        return -1;
    }
    
    public GraphNode<E> getNodeByIndex(int index) {
        GraphNode<E> current = first;
        int currentIndex = 0;
        while (current != null) {
            if (currentIndex == index) {
                return current;
            }
            current = current.next;
            currentIndex++;
        }
        return null;
    }

    public GraphNode<E> getNodeByData(E data) {
        GraphNode<E> current = first;
        while (current != null) {
            if (current.data.equals(data)) {
                return current;
            }
            current = current.next;
        }
        return null;
    }


    public float shortestPathKm(Graph<E> graph, E startNode, E endNode) {
        GraphNode<E> start = getNodeByData(startNode);
        if (start == null) {
            return -1;
        }
    
        GraphNode<E> end = getNodeByData(endNode);
        if (end == null) {
            return -1;
        }
    
        Array<Float> distances = new Array<>(graph.getSize());
        for (int i = 0; i < graph.getSize(); i++) {
            distances.add(Float.POSITIVE_INFINITY);
        }

        distances.set(graph.getNodeIndex(startNode), 0f);

        Array<Boolean> visited = new Array<>(graph.getSize());
        for (int i = 0; i < graph.getSize(); i++) {
            visited.add(false);
        }

        for (int i = 0; i < graph.getSize(); i++) {
            int minIndex = minDistance(distances, visited);
            visited.set(minIndex, true);

            GraphNode<E> currentNode = getNodeByIndex(minIndex);
            for (Edge<E> edge = currentNode.list.first; edge != null; edge = edge.next) {
                int adjIndex = graph.getNodeIndex(edge.destination);
                float newDistance = distances.get(minIndex) + edge.weight;
                if (!visited.get(adjIndex) && newDistance < distances.get(adjIndex)) {
                    distances.set(adjIndex, newDistance);
                }
            }
        }

        return distances.get(graph.getNodeIndex(endNode));
    }


    private int minDistance(Array<Float> distances, Array<Boolean> visited) {
        float min = Float.POSITIVE_INFINITY;
        int minIndex = -1;

        if (distances.size() != visited.size()) {
            throw new IllegalArgumentException("Los arrays distances y visited deben tener el mismo tamaño.");
        }

        for (int v = 0; v < distances.size(); v++) {
            if (!visited.get(v) && distances.get(v) <= min) {
                min = distances.get(v);
                minIndex = v;
            }
        }
        return minIndex;
    }

    public LinkedList<E> shortestPath(Graph<E> graph, E startNode, E endNode) {
        // Obtener el nodo de inicio
        LinkedList<E> shortestPath = new LinkedList<>();
        GraphNode<E> start = getNodeByData(startNode);
        if (start == null) {
            return shortestPath;
        }

        // Obtener el nodo de destino
        GraphNode<E> end = getNodeByData(endNode);
        if (end == null) {
            return shortestPath;
        }

        // Inicializar las distancias desde el nodo de inicio a todos los demás nodos como infinito
        Array<Float> distances = new Array<>(graph.getSize());
        for (int i = 0; i < graph.getSize(); i++) {
            distances.add(Float.POSITIVE_INFINITY);
        }
        distances.set(graph.getNodeIndex(startNode), 0f);

        // Array para almacenar los nodos visitados
        Array<Boolean> visited = new Array<>(graph.getSize());
        for (int i = 0; i < graph.getSize(); i++) {
            visited.add(false);
        }

        // Array para almacenar el camino más corto desde el nodo de inicio hasta cada nodo
        Array<Integer> previous = new Array<>(graph.getSize());
        for (int i = 0; i < graph.getSize(); i++) {
            previous.add(-1); // Inicialmente no hay nodos previos
        }

        // Algoritmo de Dijkstra
        for (int i = 0; i < graph.getSize(); i++) {
            // Encontrar el nodo no visitado más cercano
            int minIndex = minDistance(distances, visited);
            visited.set(minIndex, true);

            // Actualizar las distancias a los nodos adyacentes
            GraphNode<E> currentNode = graph.getNodeByIndex(minIndex);
            for (Edge<E> edge = currentNode.list.first; edge != null; edge = edge.next) {
                int adjIndex = graph.getNodeIndex(edge.destination);
                float newDistance = distances.get(minIndex) + edge.weight;
                if (!visited.get(adjIndex) && newDistance < distances.get(adjIndex)) {
                    distances.set(adjIndex, newDistance);
                    previous.set(adjIndex, minIndex);
                }
            }
        }

        // Construir el camino más corto
        int endIdx = graph.getNodeIndex(endNode);
        while (endIdx != graph.getNodeIndex(startNode)) {
            shortestPath.add(graph.getNodeByIndex(endIdx).data);
            endIdx = previous.get(endIdx);
        }
        shortestPath.add(startNode);
        shortestPath.reverse();

        return shortestPath;
    }
}
