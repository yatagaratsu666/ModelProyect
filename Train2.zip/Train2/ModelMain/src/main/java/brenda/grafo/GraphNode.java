package brenda.grafo;

import java.io.Serializable;

public class GraphNode<E> implements Serializable{
    
    public  E data;
    public AdjacencyList<E> list;
    public GraphNode<E> next;
    
    public GraphNode(E element) {
        this.data = element;
        this.list = new AdjacencyList<>();
        this.next = null;
    }
}
