
package brenda.util.priorityqueue;

import brenda.util.collection.AbstractCollection;
import java.io.Serializable;

public abstract class AbstractPriorityQueue<E> extends AbstractCollection<E> implements PriorityQueue<E>, Serializable{
    
}
