
package brenda.util.node;

import java.io.Serializable;

public abstract class AbstractNode<E> implements Node<E>, Cloneable, Serializable {
    protected E element;
    
    public AbstractNode(){
        this.element = null;
    }

    public AbstractNode(E element) {
        this.element = element;
    }
    
    @Override
    public void set(E element){
        this.element = element;
    }
    
    @Override
    public E get(){
        return element;
    }
    
    @Override
    public String toString(){
        return element.toString();
    }
}
