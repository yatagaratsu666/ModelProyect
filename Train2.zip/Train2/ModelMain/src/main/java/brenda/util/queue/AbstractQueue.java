
package brenda.util.queue;

import brenda.util.collection.AbstractCollection;
import java.io.Serializable;

public abstract class AbstractQueue<E> extends AbstractCollection<E> implements Queue<E>, Serializable{
    
}
