
package brenda.util.stack;

import brenda.util.collection.AbstractCollection;
import java.io.Serializable;

public abstract class AbstractStack<E> extends AbstractCollection<E> implements Stack<E>, Serializable{
    
}
