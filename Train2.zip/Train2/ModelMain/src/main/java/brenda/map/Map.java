
package brenda.map;

import brenda.array.Array;
import brenda.doublycircularlist.LinkedListDoubly;
import brenda.model.map.AbstractMap;
import java.io.Serializable;

public class Map<E> extends AbstractMap<E> implements Serializable {

    Array<LinkedListDoubly<E>> array;
    int dimension;
    int colisiones;

    public Map(int size) {
        this.dimension = size;
        array = new Array<>(size);
        for (int i = 0; i < size; i++) {
            array.add(new LinkedListDoubly<>());
        }
    }

    public int encontrarIndice(String k) {
        int factor = 31;
        int key = 0;
        for (int i = 0; i < k.length(); i++) {
            key = (key * factor) + k.charAt(i);
        }
        int value = Math.abs(key) % dimension;
        return value;
    }

    @Override
    public boolean put(String k, E obj) {
        int index = encontrarIndice(k);
        if (!array.get(index).isEmpty()) {
            colisiones++;
        }
        array.get(index).add(obj);
        return true;
    }

    @Override
    public E get(String k) {
        return array.get(encontrarIndice(k)).peek();
    }

    @Override
    public int colisiones() {
        return colisiones;
    }

    public int size() {
        int count = 0;
        for (int i = 0; i < dimension; i++) {
            count += array.get(i).size();
        }
        return count;
    }
}
