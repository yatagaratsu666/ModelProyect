
package brenda.nodesingly;

import brenda.util.node.AbstractNode;
import java.io.Serializable;

public class LinkedNode<E> extends AbstractNode<E> implements Serializable{
    
    private LinkedNode<E> next;
    
    public LinkedNode() {
        super();
        next = null;
    }
    
    public LinkedNode<E> getNext() {
        return next;
    }

    public LinkedNode(E element) {
        super(element);
        next = null;
    }
    
    public void setNext(LinkedNode<E> next){
        this.next = next;
    }
    
}
