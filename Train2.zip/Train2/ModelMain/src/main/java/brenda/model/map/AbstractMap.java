
package brenda.model.map;

import java.io.Serializable;


public abstract class AbstractMap<E> implements Map<E>, Serializable{
    
}
