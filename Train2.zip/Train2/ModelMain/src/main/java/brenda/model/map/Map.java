
package brenda.model.map;


public interface Map<E> {
    public boolean put(String k, E obj);
    public E get (String k);
    public int colisiones();
}
