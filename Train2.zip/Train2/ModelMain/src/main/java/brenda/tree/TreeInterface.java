
package brenda.tree;


public interface TreeInterface {
    
}
