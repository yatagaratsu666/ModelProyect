
package brenda.tree;

import java.io.Serializable;


public abstract class AbstractTree<E> implements TreeInterface, Serializable{
    
}
