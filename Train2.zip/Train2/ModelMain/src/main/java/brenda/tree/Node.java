
package brenda.tree;

import java.io.Serializable;


public class Node<E> implements Cloneable, Serializable{
    
    protected E root;
    protected Node<E> right;
    protected Node<E> left;
    
    public Node (E element){
        root = element;
        right = null;
        left = null;
    }
    
    public Node(E element, Node<E> derecha, Node<E> izquierda){
        root = element;
        right = derecha;
        left = izquierda;
    }

    public void setDer(Node<E> der) {
        this.right = der;
    }

    public void setIzq(Node<E> izq) {
        this.left = izq;
    }
    
    public void setRoot(E element){
        this.root = element;
    }
    
    public E valorNodo(){
        return root;
    }
    
    public Node<E> valorDer(){
        return right;
    }
    
    public Node<E> valorIzq(){
        return left;
    }
}
