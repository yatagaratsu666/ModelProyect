
package brenda.tree;

import brenda.list.queue.Queue;
import brenda.listsingly.LinkedList;
import java.io.Serializable;

public class BinaryTree<E> extends AbstractTree<E> implements Serializable {

    protected Node<E> root;

    public BinaryTree() {
        root = null;
    }

    public BinaryTree(E element) {
        root = new Node<>(element);
    }

    public BinaryTree(E element, Node<E> der, Node<E> izq) {
        root = new Node<>(element, der, izq);
    }

    public void setRoot(Node<E> root) {
        this.root = root;
    }

    public Node<E> MostrarRaiz() {
        return root;
    }

    public Node<E> HijoDer() {
        return root.valorDer();
    }

    public Node<E> HijoIzq() {
        return root.valorIzq();
    }

    public boolean isEmpty() {
        return root == null;
    }

    private void preOrdenR(Node<E> r, LinkedList<E> list) {
        if (r != null) {
            list.add(r.valorNodo());
            preOrdenR(r.valorIzq(), list);
            preOrdenR(r.valorDer(), list);
        }
    }

    public LinkedList<E> preOrder() {
        LinkedList<E> list = new LinkedList<>();
        preOrdenR(root, list);
        return list;
    }

    public LinkedList<E> inOrden() {
        LinkedList<E> list = new LinkedList<>();
        inOrdenR(root, list);
        return list;
    }

    public LinkedList<E> postOrden() {
        LinkedList<E> list = new LinkedList<>();
        postOrdenR(root, list);
        return list;
    }

    private void inOrdenR(Node<E> r, LinkedList<E> list) {
        if (r != null) {
            inOrdenR(r.valorIzq(), list);
            list.add(r.valorNodo());
            inOrdenR(r.valorDer(), list);
        }
    }

    private void postOrdenR(Node<E> r, LinkedList<E> list) {
        if (r != null) {
            postOrdenR(r.valorIzq(), list);
            postOrdenR(r.valorDer(), list);
            list.add(r.valorNodo());
        }
    }

//    public void busquedaAnchura(Node<E> r, LinkedList<E> list){
//        if (r == null)
//            return;
//        
//        Queue<Node<E>> queue = new Queue();
//        queue.insert(r);
//
//        while (!queue.isEmpty()) {
//            Node<E> currentNode = queue.extract();
//            list.add(currentNode.valorNodo());
//
//            if (currentNode.valorIzq() != null)
//                queue.insert(currentNode.valorIzq());
//            if (currentNode.valorDer() != null)
//                queue.insert(currentNode.valorDer());
//        }
//    }
    public int calcularAnchura() {
        if (root == null) {
            return 0;
        }

        Queue<Node<E>> queue = new Queue<>();
        queue.insert(root);

        int maxAnchura = 0;

        while (!queue.isEmpty()) {
            int nivelSize = queue.size();
            maxAnchura = Math.max(maxAnchura, nivelSize);

            for (int i = 0; i < nivelSize; i++) {
                Node<E> currentNode = queue.extract();
                if (currentNode.valorIzq() != null) {
                    queue.insert(currentNode.valorIzq());
                }
                if (currentNode.valorDer() != null) {
                    queue.insert(currentNode.valorDer());
                }
            }
        }
        return maxAnchura;
    }

    public int calcularAltura(Node<E> node) {
        if (node == null) {
            return -1;
        } else {
            int leftWidth = calcularAltura(node.valorIzq());
            int rightWidth = calcularAltura(node.valorDer());
            int maxChildWidth;

            if (leftWidth > rightWidth) {
                maxChildWidth = leftWidth;
            } else {
                maxChildWidth = rightWidth;
            }

            return 1 + maxChildWidth;
        }
    }

    public boolean esArbolCompleto(Node<E> root) {
        if (root == null) {
            return true;
        }

        Queue<Node<E>> queue = new Queue<>();
        queue.insert(root);

        boolean encontramosNodoIncompleto = false;

        while (!queue.isEmpty()) {
            Node<E> currentNode = queue.extract();

            if (encontramosNodoIncompleto) {
                if (currentNode.valorIzq() != null || currentNode.valorDer() != null) {
                    return false;
                }
            } else {
                if (currentNode.valorIzq() != null && currentNode.valorDer() != null) {
                    queue.insert(currentNode.valorIzq());
                    queue.insert(currentNode.valorDer());
                } else if (currentNode.valorIzq() == null && currentNode.valorDer() != null) {
                    encontramosNodoIncompleto = true;
                    return false;
                } else if (currentNode.valorIzq() != null && currentNode.valorDer() == null) {
                    encontramosNodoIncompleto = true;
                } else {
                    encontramosNodoIncompleto = true;
                }
            }
        }

        return true;
    }

    public void removerNodo(E valor) {
        root = removerNodoRecursivo(root, valor);
    }

    private Node<E> removerNodoRecursivo(Node<E> nodo, E valor) {
        if (nodo == null) {
            return null;
        }

        if (valor.equals(nodo.valorNodo())) {
            if (nodo.valorIzq() != null && nodo.valorDer() != null) {
                Node<E> sucesor = encontrarSucesor(nodo.valorDer());
                nodo.setRoot(sucesor.valorNodo());
                nodo.setDer(removerNodoRecursivo(nodo.valorDer(), sucesor.valorNodo()));
            } else if (nodo.valorIzq() != null) {
                nodo = nodo.valorIzq();
            } else if (nodo.valorDer() != null) {
                nodo = nodo.valorDer();
            } else {
                nodo = null;
            }
        } else if (valor.hashCode() < nodo.valorNodo().hashCode()) {
            nodo.setIzq(removerNodoRecursivo(nodo.valorIzq(), valor));
        } else {
            nodo.setDer(removerNodoRecursivo(nodo.valorDer(), valor));
        }

        return nodo;
    }

    private Node<E> encontrarSucesor(Node<E> nodo) {
        while (nodo.valorIzq() != null) {
            nodo = nodo.valorIzq();
        }
        return nodo;
    }

    public void insertar(E valor) {
        if (root == null) {
            root = new Node<>(valor);
        } else {
            Queue<Node<E>> cola = new Queue<>();
            cola.insert(root);

            while (!cola.isEmpty()) {
                Node<E> nodoActual = cola.extract();

                if (nodoActual.valorIzq() == null) {
                    nodoActual.setIzq(new Node<>(valor));
                    return;
                } else {
                    cola.insert(nodoActual.valorIzq());
                }

                if (nodoActual.valorDer() == null) {
                    nodoActual.setDer(new Node<>(valor));
                    return;
                } else {
                    cola.insert(nodoActual.valorDer());
                }
            }
        }
    }
}
