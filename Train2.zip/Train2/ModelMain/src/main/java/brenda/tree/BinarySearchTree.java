
package brenda.tree;

import brenda.list.queue.Queue;
import brenda.listsingly.LinkedList;
import java.io.Serializable;

public class BinarySearchTree<E> extends AbstractTree<E> implements Serializable {

    protected Node<E> root;

    public BinarySearchTree() {
        root = null;
    }

    public BinarySearchTree(E element) {
        root = new Node<>(element);
    }

    public BinarySearchTree(E element, Node<E> right, Node<E> left) {
        root = new Node<>(element, right, left);
    }

    public void setRoot(Node<E> root) {
        this.root = root;
    }

    public Node<E> getRoot() {
        return root;
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void insert(E value) {
        root = insertRecursive(root, value);
    }

    private Node<E> insertRecursive(Node<E> node, E value) {
        if (node == null) {
            return new Node<>(value);
        }

        if (value.equals(node.valorNodo())) {
        } else if (esMenor(value, node.valorNodo())) {
            node.setIzq(insertRecursive(node.valorIzq(), value));
        } else {
            node.setDer(insertRecursive(node.valorDer(), value));
        }

        return node;
    }

    private boolean esMenor(E valor1, E valor2) {
        if (valor1.equals(valor2)) {
            return false;
        }

        if (valor1 == null) {
            return true;
        }
        if (valor2 == null) {
            return false;
        }

        return valor1.hashCode() < valor2.hashCode();
    }

    public LinkedList<E> inOrden() {
        LinkedList<E> list = new LinkedList<>();
        inOrdenRecursivo(root, list);
        return list;
    }

    private void inOrdenRecursivo(Node<E> node, LinkedList<E> list) {
        if (node != null) {
            inOrdenRecursivo(node.valorIzq(), list);
            list.add(node.valorNodo());
            inOrdenRecursivo(node.valorDer(), list);
        }
    }

    public LinkedList<E> preOrden() {
        LinkedList<E> list = new LinkedList<>();
        preOrdenRecursivo(root, list);
        return list;
    }

    private void preOrdenRecursivo(Node<E> node, LinkedList<E> list) {
        if (node != null) {
            list.add(node.valorNodo());
            preOrdenRecursivo(node.valorIzq(), list);
            preOrdenRecursivo(node.valorDer(), list);
        }
    }

    public LinkedList<E> postOrden() {
        LinkedList<E> list = new LinkedList<>();
        postOrdenRecursivo(root, list);
        return list;
    }

    private void postOrdenRecursivo(Node<E> node, LinkedList<E> list) {
        if (node != null) {
            postOrdenRecursivo(node.valorIzq(), list);
            postOrdenRecursivo(node.valorDer(), list);
            list.add(node.valorNodo());
        }
    }

    public LinkedList<E> busquedaPorAnchura() {
        LinkedList<E> list = new LinkedList<>();
        if (root == null) {
            return list;
        }
        Queue<Node<E>> queue = new Queue<>();
        queue.insert(root);
        while (!queue.isEmpty()) {
            Node<E> currentNode = queue.extract();
            list.add(currentNode.valorNodo());

            if (currentNode.valorIzq() != null) {
                queue.insert(currentNode.valorIzq());
            }
            if (currentNode.valorDer() != null) {
                queue.insert(currentNode.valorDer());
            }
        }
        return list;
    }

    public LinkedList<Node<E>> busquedaPorAnchura(Node<E> nodoBuscado) {
        LinkedList<Node<E>> camino = new LinkedList<>();
        if (root == null) {
            return camino;
        }
        Queue<Node<E>> queue = new Queue<>();
        queue.insert(root);
        while (!queue.isEmpty()) {
            Node<E> currentNode = queue.extract();
            camino.add(currentNode);
            if (currentNode.equals(nodoBuscado)) {
                return camino;
            }
            if (currentNode.valorIzq() != null) {
                queue.insert(currentNode.valorIzq());
            }
            if (currentNode.valorDer() != null) {
                queue.insert(currentNode.valorDer());
            }
        }

        return new LinkedList<>();
    }

    public LinkedList<Node<E>> busquedaPorAltura(Node<E> nodoBuscado) {
        if (root == null) {
            return new LinkedList<>();
        }
        return buscarCaminoPorAltura(root, nodoBuscado);
    }

    private LinkedList<Node<E>> buscarCaminoPorAltura(Node<E> currentNode, Node<E> nodoBuscado) {
        LinkedList<Node<E>> camino = new LinkedList<>();
        camino.add(currentNode);
        if (currentNode.equals(nodoBuscado)) {
            return camino;
        }
        if (currentNode.valorIzq() != null) {
            LinkedList<Node<E>> caminoIzquierdo = buscarCaminoPorAltura(currentNode.valorIzq(), nodoBuscado);
            if (!caminoIzquierdo.isEmpty()) {
                return caminoIzquierdo;
            }
        }
        if (currentNode.valorDer() != null) {
            LinkedList<Node<E>> caminoDerecho = buscarCaminoPorAltura(currentNode.valorDer(), nodoBuscado);
            if (!caminoDerecho.isEmpty()) {
                return caminoDerecho;
            }
        }
        return new LinkedList<>();
    }

    public void insertar(E valor) {
        root = insertarRecursivo(root, valor);
    }

    private Node<E> insertarRecursivo(Node<E> nodo, E valor) {
        if (nodo == null) {
            return new Node<>(valor);
        }
        if (esMenor(valor, nodo.valorNodo())) {
            nodo.setIzq(insertarRecursivo(nodo.valorIzq(), valor));
        } else if (!esMenor(valor, nodo.valorNodo())) {
            nodo.setDer(insertarRecursivo(nodo.valorDer(), valor));
        }
        return nodo;
    }

    public void remover(E valor) {
        root = removerRecursivo(root, valor);
    }

    private Node<E> removerRecursivo(Node<E> nodo, E valor) {
        if (nodo == null) {
            return null;
        }

        if (esMenor(valor, nodo.valorNodo())) {
            nodo.setIzq(removerRecursivo(nodo.valorIzq(), valor));
        } else if (!esMenor(valor, nodo.valorNodo())) {
            nodo.setDer(removerRecursivo(nodo.valorDer(), valor));
        } else {
            if (nodo.valorIzq() != null && nodo.valorDer() != null) {
                Node<E> sucesor = encontrarSucesor(nodo.valorIzq());
                nodo.setRoot(sucesor.valorNodo());
                nodo.setIzq(removerRecursivo(nodo.valorIzq(), sucesor.valorNodo()));
            } else {
                nodo = (nodo.valorIzq() != null) ? nodo.valorIzq() : nodo.valorDer();
            }
        }

        return nodo;
    }

    private Node<E> encontrarSucesor(Node<E> nodo) {
        while (nodo.valorDer() != null) {
            nodo = nodo.valorDer();
        }
        return nodo;
    }
}
