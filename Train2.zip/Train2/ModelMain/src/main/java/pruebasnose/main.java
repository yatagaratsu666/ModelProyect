
package pruebasnose;

import brenda.listsingly.LinkedList;
import brenda.util.iterator.Iterator;


public class main {
    public static void main(String[] args) {
        Archivo archivo = new Archivo("C:\\Users\\BRENDA\\Downloads\\person\\maca.txt");
        
        Person person1 = new Person("John", 30);
        Person person2 = new Person("Alice", 25);
        Person person3 = new Person("Bob", 35);
        
//        archivo.registrar(person1);
//        archivo.registrar(person2);
//        archivo.registrar(person3);
        
//        archivo.borrarContenido();

        LinkedList<String> lineas = archivo.obtenerTextoDelArchivo();
        Iterator iterado = lineas.iterator();
        while (iterado.hasNext()) {
            System.out.println(iterado.next());
        }
    }
}
