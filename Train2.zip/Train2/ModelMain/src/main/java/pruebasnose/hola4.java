
package pruebasnose;

import brenda.priorityqueue.PriorityQueue;
import brenda.util.iterator.Iterator;

public class hola4 {
    public static void main(String[] args) {
        PriorityQueue<String> priorityQueue = new PriorityQueue<>(3);
        priorityQueue.insert(0, "Miku");////miku, kaito, len, meiko, luka, rin
        priorityQueue.insert(2, "Luka");
        priorityQueue.insert(2, "Rin");
        priorityQueue.insert(1, "Len");
        priorityQueue.insert(0, "Kaito");
        priorityQueue.insert(1, "Meiko");
        System.out.println(priorityQueue.contains("Miku"));
        Iterator iterator = priorityQueue.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
//        }
    }
}
}
