
package pruebasnose;

import brenda.listsingly.LinkedList;
import brenda.tree.BinaryTree;
import brenda.tree.Node;

public class hola2 {

    public static void main(String[] args) {
        // Creamos una lista enlazada
        LinkedList<Integer> lista = new LinkedList<>();

        // Añadimos algunos elementos a la lista
        lista.add(10);
        lista.add(20);
        lista.add(30);
        lista.add(40);
        lista.add(50);

        // Probamos el método get para obtener elementos de la lista
        System.out.println("Elemento en la posición 0: " + lista.get(0)); // Debería imprimir 10
        System.out.println("Elemento en la posición 2: " + lista.get(2)); // Debería imprimir 30
        System.out.println("Elemento en la posición 4: " + lista.get(4)); // Debería imprimir 50

        // Intentamos obtener un elemento fuera de los límites de la lista (debería lanzar una excepción)
        try {
            System.out.println("Elemento en la posición 5: " + lista.get(5));
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Excepción atrapada: " + e.getMessage()); // Debería imprimir "Index out of bounds"
        }
    }
}
