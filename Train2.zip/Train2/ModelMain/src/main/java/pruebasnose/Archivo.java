
package pruebasnose;

import brenda.listsingly.LinkedList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Archivo {
    private String nombreArchivo;

    public Archivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public boolean agregarValor(String valor) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo, true))) {
            writer.write(valor);
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean registrar(Person persona) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo, true))) {
            writer.write(persona.toString());
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public LinkedList<String> obtenerTextoDelArchivo() {
        LinkedList<String> lineasDeTexto = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lineasDeTexto.add(linea);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lineasDeTexto;
    }

    private File obtenerArchivo() {
        try {
            return new File(nombreArchivo);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public boolean borrarContenido() {
        try {
            File archivo = obtenerArchivo();
            if (archivo.exists()) {
                FileWriter fw = new FileWriter(archivo);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("");
                bw.close();
                return true;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
