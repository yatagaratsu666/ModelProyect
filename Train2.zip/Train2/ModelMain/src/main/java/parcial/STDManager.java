package parcial;

import brenda.listsingly.LinkedList;
import brenda.util.iterator.Iterator;

public class STDManager {

    private LinkedList<Integer> data;

    public STDManager(LinkedList<Integer> data) {
        this.data = data;
    }

    public int calcularPromedio() {
        int suma = 0;
        Iterator<Integer> iterator = data.iterator();
        while (iterator.hasNext()) {
            suma += iterator.next();
        }
        return suma / data.size();
    }

    public int calcularMediana() {
        int[] sorted = new int[data.size()];
        int index = 0;
        Iterator<Integer> iterator = data.iterator();
        while (iterator.hasNext()) {
            sorted[index++] = iterator.next();
        }

        metodoBurbuja(sorted);

        int n = sorted.length;
        if (n % 2 == 0) {
            return (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
        } else {
            return sorted[n / 2];
        }
    }

    public int calcularModa() {
        Iterator<Integer> iterator = data.iterator();
        int maxValor = iterator.next();
        while (iterator.hasNext()) {
            int next = iterator.next();
            if (next > maxValor) {
                maxValor = next;
            }
        }

        int[] frecuencia = new int[maxValor + 1];
        Iterator<Integer> iteratorData = data.iterator();
        while (iteratorData.hasNext()) {
            int num = iteratorData.next();
            frecuencia[num]++;
        }

        int moda = -1;
        int maxFrecuencia = 0;
        for (int i = 0; i < frecuencia.length; i++) {
            if (frecuencia[i] > maxFrecuencia) {
                moda = i;
                maxFrecuencia = frecuencia[i];
            }
        }

        if (maxFrecuencia == 1) {
            return -1;
        }

        return moda;
    }

    private void metodoBurbuja(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    
    public int calcularFrecuencia(int moda){
        int cant = 0;
        Iterator<Integer> iterator = data.iterator();
        while (iterator.hasNext()) {
            if(iterator.next().equals(moda)){
                cant++;
            }
        }
        return cant;
    }
}
