package parcial;

import brenda.array.Array;
import brenda.priorityqueue.PriorityQueue;

public class Bag {

    private Array<PriorityQueue<Item>> items;
    private Array<Integer> capacity;

    public Bag(int dimension) {
        items.add(new PriorityQueue<>(dimension));
        capacity.add(dimension);
    }

    public boolean addItem(Item item) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).size() < capacity.get(i)) {
                if (items.get(i).contains(item)) {
                    items.get(i).insert(item);
                    return true;
                } else {
                    items.get(i).insert(item);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean addItem(Item item, int priority) {
        if (priority < 0 || priority >= items.size()) {
            return false;
        }
        if (items.get(priority).contains(item)) {
            items.get(priority).insert(item);
            return true;
        }
        for (int i = priority; i < items.size(); i++) {
            if (items.get(i).size() < capacity.get(i)) {
                items.get(i).insert(item);
                return true;
            }
        }
        return false;
    }

    public void displayPriorityList() {
        for (int i = 0; i < items.size(); i++) {
            PriorityQueue<Item> currentQueue = items.get(i);
            System.out.println("Prioridad " + i + ":");

            while (currentQueue.size() > 0) {
                Item item = currentQueue.extract();
                System.out.println(item.getName() + " - Prioridad: " + i);
            }
        }
    }

    public boolean swapItems(int index1, int index2) {
        if (index1 < 0 || index1 >= items.size() || index2 < 0 || index2 >= items.size()) {
            return false;
        }

        PriorityQueue<Item> tempQueue = items.get(index1);
        items.set(index1, items.get(index2));
        items.set(index2, tempQueue);

        int tempCapacity = capacity.get(index1);
        capacity.set(index1, capacity.get(index2));
        capacity.set(index2, tempCapacity);

        return true;
    }
}
