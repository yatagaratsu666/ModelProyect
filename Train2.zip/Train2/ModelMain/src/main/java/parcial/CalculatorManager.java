package parcial;

public class CalculatorManager {

    public String subtractNumbers(String number1, String number2) {
        int[] num1 = toIntArray(number1);
        int[] num2 = toIntArray(number2);

        if (isLessThan(num1, num2)) {
            int[] temp = num1;
            num1 = num2;
            num2 = temp;
        }

        int borrow = 0;
        StringBuilder result = new StringBuilder();
        for (int i = num1.length - 1; i >= 0; i--) {
            int diff = num1[i] - (i < num2.length ? num2[i] : 0) - borrow;
            if (diff < 0) {
                diff += 10;
                borrow = 1;
            } else {
                borrow = 0;
            }
            result.insert(0, diff);
        }
        while (result.length() > 1 && result.charAt(0) == '0') {
            result.deleteCharAt(0);
        }

        return result.toString();
    }

    public String calculateModulus(String number, String divisor) {
        int[] num = toIntArray(number);
        int[] div = toIntArray(divisor);
        while (isGreaterThanOrEqualTo(num, div)) {
            num = subtract(num, div);
        }
        return toString(num);
    }

    public int[] toIntArray(String number) {
        int[] digits = new int[number.length()];
        for (int i = 0; i < number.length(); i++) {
            digits[i] = Character.getNumericValue(number.charAt(i));
        }
        return digits;
    }

    public String toString(int[] num) {
        StringBuilder builder = new StringBuilder();
        for (int digit : num) {
            builder.append(digit);
        }
        return builder.toString();
    }

    public boolean isLessThan(int[] num1, int[] num2) {
        if (num1.length != num2.length) {
            return num1.length < num2.length;
        }
        for (int i = 0; i < num1.length; i++) {
            if (num1[i] != num2[i]) {
                return num1[i] < num2[i];
            }
        }
        return false;
    }

    public boolean isGreaterThanOrEqualTo(int[] num1, int[] num2) {
        return !isLessThan(num1, num2);
    }

    public int[] subtract(int[] num1, int[] num2) {
        boolean negative = (num1[0] < 0) ^ (num2[0] < 0);

        if (num1[0] < 0) {
            num1[0] *= -1;
        }
        if (num2[0] < 0) {
            num2[0] *= -1;
        }

        int[] result = new int[Math.max(num1.length, num2.length) + 1];
        int borrow = 0;
        for (int i = 0; i < result.length; i++) {
            int digit1 = (i < num1.length) ? num1[num1.length - 1 - i] : 0;
            int digit2 = (i < num2.length) ? num2[num2.length - 1 - i] : 0;
            int diff = digit1 - digit2 - borrow;
            if (diff < 0) {
                diff += 10;
                borrow = 1;
            } else {
                borrow = 0;
            }
            result[result.length - 1 - i] = diff;
        }
        int start = 0;
        while (start < result.length - 1 && result[start] == 0) {
            start++;
        }
        result[start] *= (negative ? -1 : 1);
        int[] finalResult = new int[result.length - start];
        System.arraycopy(result, start, finalResult, 0, finalResult.length);

        return finalResult;
    }
}
