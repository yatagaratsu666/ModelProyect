
package parcial;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileHandler {

    public String readFirstLine(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            return reader.readLine();
        }
    }

    public void writeToFile(String filePath, String content) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
        }
    }

    public void createFileWithOutPath(String filePath) throws IOException {
        // Create the file if it doesn't exist
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write an empty string to create an empty file
            writer.write("");
        }
    }
}
