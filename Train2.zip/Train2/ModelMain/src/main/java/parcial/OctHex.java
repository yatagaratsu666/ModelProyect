package parcial;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class OctHex {

    public static void main(String[] args) {
        OctHexManager manager = new OctHexManager();
        try {
            manager.result("C:\\Users\\BRENDA\\Downloads\\pruebas\\in.hex");
            System.out.println(manager.print());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
