package parcial;

import brenda.listsingly.LinkedList;
import brenda.util.iterator.Iterator;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class POLYManager {

    public LinkedList<Integer> subtractPolynomials(LinkedList<Integer> poly1, LinkedList<Integer> poly2) {
        LinkedList<Integer> result = new LinkedList<>();
        Iterator<Integer> it1 = poly1.iterator();
        Iterator<Integer> it2 = poly2.iterator();

        while (it1.hasNext() || it2.hasNext()) {
            int coefficient1 = it1.hasNext() ? it1.next() : 0;
            int power1 = it1.hasNext() ? it1.next() : 0;
            int coefficient2 = it2.hasNext() ? it2.next() : 0;
            int power2 = it2.hasNext() ? it2.next() : 0;

            if (power1 == 1 && power2 == 1) {
                result.add(coefficient1 - coefficient2);
                result.add(1);
            } else {
                result.add(coefficient1 - coefficient2);
                result.add(Math.max(power1, power2));
            }
        }

        return result;
    }

    public LinkedList<Integer> derivePolynomial(LinkedList<Integer> poly) {
        LinkedList<Integer> result = new LinkedList<>();
        Iterator<Integer> it = poly.iterator();

        while (it.hasNext()) {
            int coefficient = it.next();
            int power = it.next();

            if (power > 0) {
                result.add(coefficient * power);
                result.add(power - 1);
            } else {
                result.add(coefficient);
            }
        }

        return result;
    }

    public LinkedList<Integer> evaluatePolynomial(LinkedList<Integer> poly, int a, int b) {
        LinkedList<Integer> results = new LinkedList<>();

        for (int x = a; x <= b; x++) {
            int result = 0;
            Iterator<Integer> it = poly.iterator();

            while (it.hasNext()) {
                int coefficient = it.next();
                int power = it.next();
                result += coefficient * (int) Math.pow(x, power);
            }
            results.add(result);
        }

        return results;
    }

    public LinkedList<Integer> loadPolynomial(String filename) throws IOException {
        LinkedList<Integer> polynomial = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("x\\^");
                int coefficient;
                try {
                    coefficient = Integer.parseInt(parts[0].trim());
                } catch (NumberFormatException e) {
                    coefficient = 0;
                }
                int exponent = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 0;
                polynomial.add(coefficient);
                polynomial.add(exponent);
            }
        }
        return polynomial;
    }

    public void saveResults(String filename, LinkedList<Integer> subtractResult, LinkedList<Integer> derivative, LinkedList<Integer> evaluationResult) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.println("Resultado de la resta de polinomios:");
            savePolynomial(subtractResult, writer);

            writer.println("\nDerivada del polinomio:");
            savePolynomial(derivative, writer);

            Iterator iterator = evaluationResult.iterator();
            int i = 0;
            while (iterator.hasNext()) {
                if (i == 0) {
                    writer.println("\nResultado de evaluar el polinomio en a:");
                    writer.println(iterator.next());
                } else {
                    writer.println("\nResultado de evaluar el polinomio en b:");
                    writer.println(iterator.next());
                }
                i++;
            }
        }
    }

    public void savePolynomial(LinkedList<Integer> polynomial, PrintWriter writer) {
        Iterator<Integer> iterator = polynomial.iterator();
        while (iterator.hasNext()) {
            int coefficient = iterator.next();
            if (!iterator.hasNext()) {
                break;
            }
            int power = iterator.next();
            if (power == 0) {
                writer.println(coefficient);
            } else {
                writer.println(coefficient + "x^" + power);
            }
        }
    }
}
