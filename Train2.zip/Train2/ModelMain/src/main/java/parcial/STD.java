
package parcial;

import brenda.listsingly.LinkedList;
import brenda.util.iterator.Iterator;
import pruebasnose.Archivo;


public class STD {
    public static void main(String[] args) {
        Archivo archivo = new Archivo("C:\\Users\\BRENDA\\Downloads\\pruebas\\numeros.txt");
        Archivo resultados = new Archivo("C:\\Users\\BRENDA\\Downloads\\pruebas\\resultado.txt");
        LinkedList<String> linked = archivo.obtenerTextoDelArchivo();
        LinkedList<Integer> data = new LinkedList<>();
        Iterator iterato = linked.iterator();
        while(iterato.hasNext()){
            data.add(Integer.valueOf((String) iterato.next()));
        }

        STDManager std = new STDManager(data);
        String promedioStr = String.valueOf(std.calcularPromedio());
        String medianaStr = String.valueOf(std.calcularMediana());
        String modaStr = String.valueOf(std.calcularModa());
        String frecuenciaStr = String.valueOf(std.calcularFrecuencia(std.calcularModa()));

        resultados.agregarValor("Promedio: " + promedioStr);
        resultados.agregarValor("Mediana: " + medianaStr);
        resultados.agregarValor("Moda: " + modaStr);
        resultados.agregarValor("Frecuencia de la moda: " + frecuenciaStr);

        LinkedList<String> lineas = resultados.obtenerTextoDelArchivo();
        Iterator<String> iterador = lineas.iterator();
        while (iterador.hasNext()) {
            System.out.println(iterador.next());
        }
        
        
    }
}
