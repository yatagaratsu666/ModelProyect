
package parcial;

import java.util.Scanner;

public class Calculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CalculatorManager cm = new CalculatorManager();
        
        System.out.println("Ingrese el primer número:");
        String number1 = scanner.nextLine();

        System.out.println("Ingrese el segundo número:");
        String number2 = scanner.nextLine();

        String subtractionResult = cm.subtractNumbers(number1, number2);
        System.out.println("resta: " + subtractionResult);

        String modulusResult = cm.calculateModulus(number1, number2);
        System.out.println("módulo: " + modulusResult);

        scanner.close();
    }
}

