package parcial;

enum ItemType {
    CLOTH,
    LEATHER,
    PLATE
}

public class Item {

    String name;
    int priority;
    int rank;
    ItemType type;
    int durability;
    String description;

    public Item(String name, int priority, int rank, ItemType type, int durability, String description) {
        this.name = name;
        this.priority = priority;
        this.rank = rank;
        this.type = type;
        this.durability = durability;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public int getRank() {
        return rank;
    }

    public ItemType getType() {
        return type;
    }

    public int getDurability() {
        return durability;
    }

    public String getDescription() {
        return description;
    }
}
