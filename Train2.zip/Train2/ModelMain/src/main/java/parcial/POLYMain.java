
package parcial;

import brenda.listsingly.LinkedList;
import java.io.IOException;


public class POLYMain {

    public static void main(String[] args) {
        POLYManager main = new POLYManager();
        try {
            LinkedList<Integer> poly1 = main.loadPolynomial("C:\\Users\\BRENDA\\Downloads\\pruebas\\polinomio1.txt");
            LinkedList<Integer> poly2 = main.loadPolynomial("C:\\Users\\BRENDA\\Downloads\\pruebas\\polinomio2.txt");

            LinkedList<Integer> subtractResult = main.subtractPolynomials(poly1, poly2);
            LinkedList<Integer> derivative = main.derivePolynomial(poly1);
            LinkedList<Integer> evaluationResult = main.evaluatePolynomial(poly1, 1, 2);

            main.saveResults("C:\\Users\\BRENDA\\Downloads\\pruebas\\polyResultados.txt", subtractResult, derivative, evaluationResult);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
