
package parcial;

import brenda.listsingly.LinkedList;
import brenda.util.iterator.Iterator;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class OctHexManager {

    public TextFileHandler handler = new TextFileHandler();
    private LinkedList<String> list = new LinkedList<>();
    private LinkedList<String> result = new LinkedList<>();
    private boolean hexa = false;
    private String path = "";

    public void hexadecimalToOctal() {
        StringBuilder binary = new StringBuilder();
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            int decimal = Integer.parseInt(iterator.next(), 16);
            binary.append(String.format("%04d", Integer.parseInt(Integer.toBinaryString(decimal))));
        }

        int length = binary.length();
        if (length % 3 != 0) {
            binary.insert(0, "00".substring(0, 3 - length % 3));
        }

        result.clear();
        for (int i = 0; i <= binary.length() - 3; i += 3) {
            String octal = Integer.toString(Integer.parseInt(binary.substring(i, i + 3), 2), 8);
            result.add(octal);
        }
    }

    public void octalToHexadecimal() {
        StringBuilder binary = new StringBuilder();
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            int decimal = Integer.parseInt(iterator.next(), 8);
            binary.append(String.format("%03d", Integer.parseInt(Integer.toBinaryString(decimal))));
        }

        int length = binary.length();
        if (length % 4 != 0) {
            binary.insert(0, "0".repeat(4 - length % 4));
        }

        result.clear();
        for (int i = 0; i < binary.length(); i += 4) {
            String hex = Integer.toString(Integer.parseInt(binary.substring(i, i + 4), 2), 16).toUpperCase();
            result.add(hex);
        }
    }

    public void insert(String filename) throws IOException {
        list.clear();
        if (filename.equalsIgnoreCase("C:\\Users\\BRENDA\\Downloads\\pruebas\\in.hex")) {
            hexa = true;
        }
        path = filename;
        String n = handler.readFirstLine(path);
        char c[] = n.toCharArray();
        for (char item : c) {
            list.add(String.valueOf(item));
        }
    }

    public void write() throws IOException {
        if (hexa) {//"C:\\Users\\BRENDA\\Downloads\\pruebas\\out.oct"
            handler.createFileWithOutPath("C:\\Users\\BRENDA\\Downloads\\pruebas\\out.oct");
            path = "C:\\Users\\BRENDA\\Downloads\\pruebas\\out.oct";
        } else {
            handler.createFileWithOutPath("C:\\Users\\BRENDA\\Downloads\\pruebas\\out.hex");
            path = "C:\\Users\\BRENDA\\Downloads\\pruebas\\out.hex";
        }
        handler.writeToFile(path, print());
    }

    public String print() throws IOException {
        StringBuilder result1 = new StringBuilder();
        if (hexa) {
            hexadecimalToOctal();
            Iterator<String> iterator = result.iterator();
            while (iterator.hasNext()) {
                result1.append(iterator.next()).append("\n");
            }
        } else {
            octalToHexadecimal();
            Iterator<String> iterator = result.iterator();
            while (iterator.hasNext()) {
                result1.append(iterator.next()).append("\n");
            }
        }
        return result1.toString();
    }

    public void result(String path) throws IOException {
        insert(path);
        write();
    }
}
