
package parcial;

import brenda.stack.list.Stack;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class WebEditor {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        validateHTML("C:\\Users\\BRENDA\\Downloads\\pruebas\\base.html");
    }

    public static void validateHTML(String filename) throws FileNotFoundException, IOException {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            
            Stack<String> stack = new Stack<>();
            boolean found = false;
            String line;
            
            while ((line = br.readLine()) != null) {
                int start = 0;
                while ((start = line.indexOf('<', start)) != -1) {
                    int end = line.indexOf('>', start);
                    String base = line.substring(start + 1, end);
                    if (base.startsWith("/")) {
                        if (!stack.isEmpty()) {
                            String openingTag = stack.pop();
                            if (!("/" + openingTag).equals(base)) {
                                System.out.println("Error: <" + base + "> no tiene una etiqueta de apertura");
                                System.out.println("Error: <" + openingTag + "> no tiene una etiqueta de cierre");
                                found = true;
                            }
                        }
                    } else if (base.endsWith("/") == false) {
                        stack.push(base);
                    }
                start = end + 1;
            }
        }
        if (found == false) {
            System.out.println("Ok");
        }
    }
}
