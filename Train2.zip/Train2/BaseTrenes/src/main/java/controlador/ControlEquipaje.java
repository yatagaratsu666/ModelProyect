
package controlador;

import brenda.array.Array;
import modelo.Equipaje;

public class ControlEquipaje {
    public ControlEquipaje(){
        
    }
    
    public Array<Equipaje> asignarEquipaje(){
        return null;
    }
}
