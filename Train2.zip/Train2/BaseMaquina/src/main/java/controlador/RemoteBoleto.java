
package controlador;

import brenda.listsingly.LinkedList;
import java.rmi.Remote;
import java.rmi.RemoteException;
import modelo.Boleto;


public interface RemoteBoleto extends Remote{
    public void agregarEnLista(Boleto boleto) throws RemoteException;
    public Boolean consultarPorId(String text) throws RemoteException;
    public LinkedList<Boleto> organizar(String index) throws RemoteException;
    public LinkedList<Boleto> consultarBoletos() throws RemoteException;
}
