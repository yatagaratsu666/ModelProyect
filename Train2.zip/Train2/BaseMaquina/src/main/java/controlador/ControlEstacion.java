
package controlador;

import brenda.listsingly.LinkedList;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Properties;
import modelo.Estacion;

public class ControlEstacion implements RemoteEstacion {
    
    ControlProperties cpp;
    
    public ControlEstacion() throws RemoteException{
        this.cpp = new ControlProperties();
    }

    @Override
    public LinkedList<Estacion> consultarEstacion() throws RemoteException{
        LinkedList<Estacion> estaciones = new LinkedList<>();
        try {
            Registry registry1 = LocateRegistry.getRegistry(cpp.getProperty("IP"), 4086);
            RemoteEstacion controlEstacion = (RemoteEstacion) registry1.lookup("ControlEstacion");
            estaciones = controlEstacion.consultarEstacion() ;
        } catch (NotBoundException | RemoteException e) {

        }
        return estaciones;
    }
}
