
package controlador;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class ControlProperties {

    private Properties properties;

    public ControlProperties() {
        this.properties = new Properties();
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("ipconfig.properties")) {
            if (inputStream != null) {
                properties.load(inputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getProperty(String key) {
        return properties.getProperty(key);
    }
}
