
package controlador;

import brenda.listsingly.LinkedList;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import modelo.Boleto;
import modelo.Cliente;
import modelo.Equipaje;
import modelo.RutaEntity;
import modelo.Tren;
import modelo.TrenEntity;

public class ControlBoleto implements RemoteBoleto{
    
    Boleto boleto;
    ControlProperties cpp;
    
    public ControlBoleto() throws RemoteException{
        this.cpp = new ControlProperties();
    }
    
    public Boleto armarBoleto(String fechaCompra, Cliente cliente, RutaEntity trayectoria, TrenEntity trenEntity) throws RemoteException{
        Equipaje equipaje = new Equipaje(trayectoria.getEquipaje().getCantidadEquipajes(), trayectoria.getEquipaje().getPeso1());
        Tren tren = trenEntity.getTren();
        double precio = trayectoria.getPrecio()*trenEntity.getValor();
        boleto = new Boleto(fechaCompra, tren, cliente, equipaje, trenEntity.getCategoria(), trayectoria, precio, trenEntity.getVagon(),trenEntity.getSeccion());
        agregarEnLista(boleto);
        return boleto;
    }

    @Override
    public void agregarEnLista(Boleto boleto) throws RemoteException {
        try {
            Registry registry3 = LocateRegistry.getRegistry(cpp.getProperty("IP"), 4082);
            RemoteBoleto controlBoleto = (RemoteBoleto) registry3.lookup("ControlBoleto");
            controlBoleto.agregarEnLista(boleto);
        } catch (NotBoundException | RemoteException e) {

        }
    }
    
    @Override
    public Boolean consultarPorId(String text) throws RemoteException{
        boolean status = false;
        try {
            Registry registry3 = LocateRegistry.getRegistry(cpp.getProperty("IP"), 4082);
            RemoteBoleto controlBoleto = (RemoteBoleto) registry3.lookup("ControlBoleto");
            status = controlBoleto.consultarPorId(text);
        } catch (NotBoundException | RemoteException e) {

        }
        return status;
    }
    
    @Override
    public LinkedList<Boleto> organizar(String index) throws RemoteException{
        LinkedList<Boleto> boletow = new LinkedList<>();
        try {
            Registry registry3 = LocateRegistry.getRegistry(cpp.getProperty("IP"), 4082);
            RemoteBoleto controlBoleto = (RemoteBoleto) registry3.lookup("ControlBoleto");
            boletow = controlBoleto.organizar(index);
        } catch (NotBoundException | RemoteException e) {

        }
        return boletow;
    }
    
    @Override
    public LinkedList<Boleto> consultarBoletos() throws RemoteException{
        LinkedList<Boleto> boletow = new LinkedList<>();
        try {
            Registry registry3 = LocateRegistry.getRegistry(cpp.getProperty("IP"), 4082);
            RemoteBoleto controlBoleto = (RemoteBoleto) registry3.lookup("ControlBoleto");
            boletow = controlBoleto.consultarBoletos();
        } catch (NotBoundException | RemoteException e) {

        }
        return boletow;
    }
}
