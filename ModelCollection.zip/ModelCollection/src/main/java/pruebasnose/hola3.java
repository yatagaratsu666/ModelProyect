
package pruebasnose;

import brenda.circularlist.LinkedList;
import brenda.util.iterator.Iterator;
import java.util.function.Predicate;



public class hola3 {
    public static void main(String[] args) {
        LinkedList<Integer> list1 = new LinkedList<>();
        list1.add(5);
        list1.add(10);
        list1.add(15);
        list1.addFirst(0);
        list1.remove(7);
        Object[] array;
//        DoublyLinkedList<Integer> list2 = new DoublyLinkedList<>();
//        list2.add(12);
//        list2.add(34);
//        list2.add(345);
//        Predicate<Integer> comparator = i -> (i%2 == 0);
//        array = list.pollLastArray(2);
//        list1 = (DoublyLinkedList<Integer>) list.pollLastCollection(1);
//        for(int i = 0; i < array.length; i++ ){
//            System.out.println(array[i]);
//        }           
//        Iterator iterator = list1.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next());
//        }
        Iterator iterato = list1.iterator();
        while (iterato.hasNext()) {
            System.out.println(iterato.next());
        }
    }
}
