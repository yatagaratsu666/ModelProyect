
package brenda.priorityqueue;

import brenda.array.Array;
import brenda.list.queue.Queue;
import brenda.util.iterator.Iterator;
import brenda.util.priorityqueue.AbstractPriorityQueue;


public class PriorityQueue<E> extends AbstractPriorityQueue<E>{
    
    Array<Queue<E>> priority;
    int prioridades;
    public PriorityQueue(int amtData){
        priority = new Array(amtData);
        this.prioridades = amtData;
        for(int i = 0; i < amtData; i++){
            priority.add(new Queue<>());
        }
    }

    @Override
    public boolean reverse() {
        return priority.reverse();
    }

    @Override
    public boolean clear() {
        for(int i = 0; i < prioridades; i++){
            priority.get(i).clear();
        }
        return true;
    }

    @Override
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean insert(E element) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean insert(int index, E element) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public E peek() {
        return priority.get(0).peek();
    }

    @Override
    public E extract() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
