
package brenda.util.stack;

import brenda.util.collection.AbstractCollection;

public abstract class AbstractStack<E> extends AbstractCollection<E> implements Stack<E>{
    
}
