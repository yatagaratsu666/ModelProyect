
package brenda.util.priorityqueue;

import brenda.util.collection.AbstractCollection;

public abstract class AbstractPriorityQueue<E> extends AbstractCollection<E> implements PriorityQueue<E>{
    
}
