
package brenda.util.queue;

import brenda.util.collection.AbstractCollection;

public abstract class AbstractQueue<E> extends AbstractCollection<E> implements Queue<E>{
    
}
