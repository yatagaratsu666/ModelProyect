
package brenda.list.queue;

import brenda.listsingly.LinkedList;
import brenda.util.collection.Collection;
import brenda.util.iterator.Iterator;
import brenda.util.queue.AbstractQueue;
import java.util.function.Function;


public class Queue<E> extends AbstractQueue<E> {
    
    LinkedList<E> linkedlist;
    
    public Queue(){
        linkedlist = new LinkedList<>();
    }

    @Override
    public E peek() {
        return linkedlist.peek();
    }

    @Override
    public E extract() {
        return linkedlist.poll();
    }

    @Override
    public boolean insert(E element) {
        return linkedlist.add(element);
    }

    @Override
    public boolean reverse() {
        return linkedlist.reverse();
    }

    @Override
    public boolean clear() {
        return linkedlist.clear();
    }

    @Override
    public Iterator<E> iterator() {
        return linkedlist.iterator();
    }
    
    @Override
    public boolean isEmpty(){
        return linkedlist.isEmpty();
    }
    
        @Override
    public int size(){
        return linkedlist.size();
    }

    @Override
    public void forEach(Function<E, Void> action){
        linkedlist.forEach(action);
    }

    @Override
    public boolean contains(E element){
        return linkedlist.contains(element);
    }


    @Override
    public boolean contains(E[] array) {
        return linkedlist.contains(array);
    }


    @Override
    public boolean contains(Collection<E> collection) {
        return linkedlist.contains(collection);
    }
    
    
    
}
